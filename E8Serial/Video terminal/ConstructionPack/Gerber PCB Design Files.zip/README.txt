These are the Gerber files which define the printed circuit board.
Copyright 2014 Geoff Graham  (http://geoffg.net)

The files are:
   Terminal.GTL   Top Copper (GTL)
   Terminal.GTS   Top Soldermask (GTS)
   Terminal.GTO   Top Silkscreen (GTO)
   Terminal.GBL   Bottom Copper (GBL)
   Terminal.GBS   Bottom Soldermask (GBS)
   Terminal.TXT   Drill File (2:4 leading)

Note that the drill file type is "2:4 leading" and this must be
specified to the PCB fabrication company.


These files and the design is licensed under a Creative Commons
Attribution-NonCommercial-ShareAlike 3.0 Australia (CC BY-NC-SA 3.0).
For details go to: http://creativecommons.org/licenses/by-nc-sa/3.0/au
